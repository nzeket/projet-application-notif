
const nodemailer = require ('nodemailer')
const transporter = nodemailer.createTransport({
    service :"hotmail",
    auth: {
        user:"evaluinsa@outlook.fr",
        pass:"oyomABANG@98",

    }
})

const options = {
    from: "evaluinsa@outlook.fr",
    to: "nzeketa21@gmail.com",
    subject:"Notification d'ajout d'un commentaire",
    text:" Un élève vient d'ajouter un commentaire sur la plateforme, connectez-vous pour y avoir accès.",
};

transporter.sendMail(options, function(err, info){
    if (err){
        console.log(err);
        return;

    }
    console.log("sent: " + info.response);
});
